
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "Queue.h"

int numWithin(Graph g, int src, int dist) {
	Queue q = QueueNew();
	QueueEnqueue(q, src);
	bool visited[GraphNumVertices(g)];
	for (int i = 0; i < GraphNumVertices(g); i++) visited[i] = false;
	visited[src] = true;

	int totalWithin = 1;
	int currDist = 0;
	while (!QueueIsEmpty(q) && currDist < dist) {
		Vertex curr = QueueDequeue(q);
		for (Vertex v = 0; v < GraphNumVertices(g); v++) {
			if (GraphIsAdjacent(g, curr, v) && !visited[v]) {
				QueueEnqueue(q, v);
				totalWithin++;
				visited[v] = true;
			}
		}
		currDist++;
	}

	return totalWithin;
}

