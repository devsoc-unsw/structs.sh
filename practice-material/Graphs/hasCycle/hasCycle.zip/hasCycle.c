
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "Graph.h"
#include "Stack.h"


bool dfsCycleCheck(Graph g, int src, int prev, bool *visited) {
	visited[src] = true;
	for (int v = 0; v < GraphNumVertices(g); v++) {
		if (GraphIsAdjacent(g, src, v)) {
			if (visited[v] && prev != v) {
				
				return true;
			}
			if (!visited[v] && dfsCycleCheck(g, v, src, visited)) return true;
		}
	}
	return false;
}

bool hasCycle(Graph g) {
	bool *visited = malloc(sizeof(bool) * GraphNumVertices(g));
	for (int i = 0; i < GraphNumVertices(g); i++) visited[i] = false;
	for (int i = 0; i < GraphNumVertices(g); i++) {
		if (!visited[i]) {
			if (dfsCycleCheck(g, 0, 0, visited)) return true;
		}
	}
	return false;
}



