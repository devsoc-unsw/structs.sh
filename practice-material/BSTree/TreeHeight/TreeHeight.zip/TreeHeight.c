
#include <stdlib.h>

#include "tree.h"

int TreeHeight(Tree t) {
    return -1;
}

