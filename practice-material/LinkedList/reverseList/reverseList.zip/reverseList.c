
#include "list.h"

void listReverse(List l) {
	// TODO
}

