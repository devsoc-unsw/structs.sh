
#include "list.h"

int listDeleteLargest(List l) {
	return -1;
}

